using System; 
using System.Drawing; 
using System.Drawing.Imaging; 
using System.IO; 
 
namespace BloxFruitsBot 
{ 
    public class ScreenshotManager 
    { 
        public static string CaptureWindow(IntPtr hWnd, string savePath) 
        { 
            if (hWnd == IntPtr.Zero) 
            { 
                throw new ArgumentNullException(nameof(hWnd), "視窗句柄不能為空。"); 
            } 
 
            Win32.RECT rect; 
            Win32.GetWindowRect(hWnd, out rect); 
 
            int width = rect.Right - rect.Left; 
            int height = rect.Bottom - rect.Top; 
 
            if (width == 0 || height == 0) 
            { 
                throw new InvalidOperationException("無法獲取視窗尺寸，寬度或高度為零。"); 
            } 
 
            Bitmap bmp = new Bitmap(width, height, PixelFormat.Format32bppArgb); 
            Graphics gfx = Graphics.FromImage(bmp); 
            IntPtr hdcBitmap = gfx.GetHdc(); 
 
            IntPtr hdcWindow = Win32.GetWindowDC(hWnd); 
            if (hdcWindow == IntPtr.Zero) 
            { 
                gfx.ReleaseHdc(hdcBitmap); 
                gfx.Dispose(); 
                bmp.Dispose(); 
                throw new InvalidOperationException("無法獲取視窗 DC。"); 
            } 
 
            try 
            { 
                Win32.BitBlt(hdcBitmap, 0, 0, width, height, hdcWindow, 0, 0, Win32.SRCCOPY); 
            } 
            finally 
            { 
                gfx.ReleaseHdc(hdcBitmap); 
                Win32.ReleaseDC(hWnd, hdcWindow); 
            } 
 
            string filePath = Path.Combine(savePath, $"screenshot_{DateTime.Now:yyyyMMddHHmmssfff}.png"); 
            bmp.Save(filePath, ImageFormat.Png); 
            gfx.Dispose(); 
            bmp.Dispose(); 
 
            return filePath; 
        } 
    } 
}
