using System; 
using System.Text.Json.Serialization; 
 
namespace BloxFruitsBot 
{ 
    public class PythonResponse 
    { 
        [JsonPropertyName("HpRatio")] 
        public double HpRatio { get; set; } 
 
        [JsonPropertyName("EnergyRatio")] 
        public double EnergyRatio { get; set; } 
 
        [JsonPropertyName("TargetVisible")] 
        public bool TargetVisible { get; set; } 
 
        [JsonPropertyName("TargetId")] 
        public string TargetId { get; set; } 
 
        [JsonPropertyName("DecisionIntent")] 
        public string DecisionIntent { get; set; } 
    } 
}
